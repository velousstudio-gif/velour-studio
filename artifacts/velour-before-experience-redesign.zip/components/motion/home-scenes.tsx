'use client';

import { useEffect, useLayoutEffect, useRef, useSyncExternalStore, type RefObject } from 'react';
import type { ScrollTrigger } from 'gsap/ScrollTrigger';
import { loadScrollMotion, motionSettings } from '@/lib/motion';
import { useMotionPreferences } from '../motion';

function HeroTimeline({ reduced, root }: { reduced: boolean; root: RefObject<HTMLElement | null> }) {
  useEffect(() => {
    const hero = root.current?.querySelector<HTMLElement>('.agency-hero');
    const header = document.querySelector<HTMLElement>('[data-home-header]');
    if (!hero) return;
    let cancelled = false;
    let context: gsap.Context | undefined;
    let observer: MutationObserver | undefined;
    const finish = () => {
      hero.dataset.heroIntro = 'complete';
      header?.setAttribute('data-intro-complete', 'true');
      window.dispatchEvent(new Event('velour:hero-complete'));
    };
    if (reduced) { finish(); return; }
    if (hero.dataset.heroIntro === 'complete') return;
    // A broken optional chunk must not leave essential content hidden.
    const failsafe = window.setTimeout(finish, 4000);
    void Promise.all([loadScrollMotion(), document.fonts.ready]).then(([{ gsap }]) => {
      if (cancelled) return;
      const start = () => {
        if (cancelled) return;
        observer?.disconnect();
        const lines = hero.querySelectorAll('.text-line-motion');
        context = gsap.context(() => {
          const timeline = gsap.timeline({ defaults: { duration: .7, ease: motionSettings.ease }, onComplete: finish });
          if (header) timeline.fromTo(header.querySelector('[data-wordmark]'), { opacity: 0 }, { opacity: 1 }, 0)
            .fromTo(header.querySelectorAll('.navigation a, .header-actions'), { opacity: 0, y: -8 }, { opacity: 1, y: 0, stagger: .035 }, .15);
          timeline.fromTo('[data-hero="eyebrow"]', { opacity: 0, y: 15 }, { opacity: 1, y: 0 }, .3)
            .fromTo(lines, { yPercent: 110, opacity: 0 }, { yPercent: 0, opacity: 1, stagger: .12 }, .4)
            .fromTo('[data-hero="accent"]', { opacity: 0, y: 22 }, { opacity: 1, y: 0 }, .65)
            .fromTo('[data-hero="description"]', { opacity: 0, y: 20 }, { opacity: 1, y: 0 }, .8)
            .fromTo('[data-hero="actions"]', { opacity: 0, y: 20 }, { opacity: 1, y: 0 }, .95)
            .fromTo('.image-mask', { clipPath: 'inset(100% 0 0 0)' }, { clipPath: 'inset(0% 0 0 0)', duration: 1.2 }, 1.05)
            .fromTo('.image-reveal-inner', { scale: 1.1 }, { scale: 1, duration: 1.2 }, 1.05);
          // Back/forward restoration and direct contact links must never replay a hidden hero.
          if (window.scrollY > 80 || (location.hash && location.hash !== '#inicio')) timeline.progress(1);
        }, hero);
      };
      if (hero.querySelector('.text-line-motion')) start();
      else {
        observer = new MutationObserver(() => { if (hero.querySelector('.text-line-motion')) start(); });
        observer.observe(hero, { childList: true, subtree: true });
      }
    }).catch(finish);
    return () => { cancelled = true; clearTimeout(failsafe); observer?.disconnect(); context?.revert(); };
  }, [reduced, root]);
  return null;
}

function DesktopScenes({ enabled, tall, root }: { enabled: boolean; tall: boolean; root: RefObject<HTMLElement | null> }) {
  const aligned = useRef(false);
  // Pin wrappers must revert before React detaches or reuses the page DOM.
  useLayoutEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    let context: gsap.Context | undefined;
    let dispose = () => {};
    void Promise.all([loadScrollMotion(), document.fonts.ready]).then(([{ gsap, ScrollTrigger }]) => {
      // Descendant layout effects run before the main element's ref is attached.
      // Read the owned DOM only after the commit, including client-side returns.
      const main = root.current;
      if (cancelled || !main) return;
      const cleanups: Array<() => void> = [];
      context = gsap.context(() => {
        gsap.timeline({ scrollTrigger: { trigger: '.hero-artwork', start: 'top 65%', end: 'bottom top', scrub: true } })
          .to('.hero-image', { y: 50, scale: .95, ease: 'none' }, 0)
          .to('.artwork-caption', { y: -15, ease: 'none' }, 0)
          .to('.artwork-corner', { y: -45, ease: 'none' }, 0);

        const service = main.querySelector<HTMLElement>('.service-feature-web')!;
        const stage = service.querySelector<HTMLElement>('.service-stage')!;
        const composition = service.querySelector<HTMLElement>('.web-composition')!;
        const mockups = composition.querySelectorAll<HTMLElement>(':scope > .project-art');
        const shopify = composition.querySelector<HTMLElement>('.service-shopify-scene')!;
        if (tall) {
          // Pin only if the complete copy fits. Expanded service details remain reachable.
          const fits = stage.offsetHeight < innerHeight - 90;
          const scene = gsap.timeline({ defaults: { ease: 'none' }, scrollTrigger: {
            trigger: stage, start: fits ? 'top 90px' : 'top 65%', end: () => '+=' + Math.round(innerHeight * .95),
            pin: fits, pinSpacer: service.querySelector<HTMLElement>('.service-pin-shell')!, pinSpacing: true, scrub: .35, anticipatePin: 1, invalidateOnRefresh: true,
          } });
          scene.fromTo(mockups[0], { y: -10, rotation: -1 }, { y: 20, rotation: 1, duration: 1 }, 0)
            .fromTo(mockups[1], { y: 10, rotation: 1 }, { y: -20, rotation: -1, duration: 1 }, 0)
            .to(mockups[0], { opacity: .3, duration: .25 }, .28)
            .to(mockups[1], { opacity: 0, y: -35, duration: .25 }, .62)
            .fromTo(shopify, { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: .3 }, .65);
        }

        gsap.timeline({ scrollTrigger: { trigger: '.service-feature-automation', start: 'top 85%', end: 'bottom 15%', scrub: true } })
          .fromTo('.device-browser', { y: -10, rotation: -1 }, { y: 18, rotation: 1, ease: 'none' }, 0)
          .fromTo('.device-phone', { y: 10, rotation: 1 }, { y: -18, rotation: -1, ease: 'none' }, 0);

        const track = main.querySelector<HTMLElement>('.process-track')!;
        const steps = Array.from(track.querySelectorAll<HTMLElement>('.timeline > li'));
        const rail = track.querySelector<HTMLElement>('.process-rail > span')!;
        track.classList.add('is-scroll-story');
        const progress = gsap.quickSetter(rail, 'scaleY');
        let thresholds: number[] = [];
        let activeStep = -1;
        const updateSteps = (self: ScrollTrigger) => {
          let current = 0;
          thresholds.forEach((threshold, index) => { if (self.scroll() >= threshold) current = index; });
          if (current !== activeStep) {
            steps.forEach((step, index) => { step.dataset.phase = index === current ? 'current' : index < current ? 'past' : 'next'; });
            activeStep = current;
          }
          progress(self.progress);
        };
        ScrollTrigger.create({ trigger: track, start: 'top 52%', end: 'bottom 52%', onUpdate: updateSteps, onRefresh: self => {
          thresholds = steps.map(step => step.getBoundingClientRect().top + window.scrollY - innerHeight * .52);
          updateSteps(self);
        } });
        cleanups.push(() => { track.classList.remove('is-scroll-story'); steps.forEach(step => delete step.dataset.phase); rail.style.removeProperty('transform'); });

        main.querySelectorAll<HTMLElement>('.work-item').forEach(item => {
          gsap.timeline({ scrollTrigger: { trigger: item, start: 'top 85%', end: 'bottom 85%', scrub: .3 }, defaults: { ease: 'none' } })
            .fromTo(item.querySelector('.parallax-art'), { scale: 1.08 }, { scale: 1 }, 0)
            .fromTo(item.querySelector('.work-caption h3'), { y: 60 }, { y: 0 }, 0)
            .fromTo(item.querySelectorAll('.work-index, .work-sector, .work-caption > div:last-child'), { opacity: 0 }, { opacity: 1 }, .1);
        });

        const cta = main.querySelector<HTMLElement>('.conversion-cta')!;
        if (tall) {
          gsap.timeline({ defaults: { ease: 'none' }, scrollTrigger: {
            trigger: cta, start: 'top 80px', end: () => '+=' + Math.round(innerHeight * .6), pin: true, pinSpacer: cta.parentElement!, scrub: .3, anticipatePin: 1, invalidateOnRefresh: true,
          } }).fromTo('.cta-heading', { scale: .92 }, { scale: 1, duration: 1 }, 0)
            .fromTo(cta.querySelector('h2'), { letterSpacing: '-.029em' }, { letterSpacing: '-.035em', duration: 1 }, 0)
            .fromTo('.cta-monogram', { y: 50 }, { y: -30, duration: 1 }, 0)
            .fromTo('.cta-light', { xPercent: -6 }, { xPercent: 6, duration: 1 }, 0)
            .fromTo('.cta-actions', { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: .35 }, .6);
        }

        const footerColumns = document.querySelectorAll('.home-main ~ .footer .footer-top > :not(a)');
        gsap.fromTo(footerColumns, { opacity: 0, y: 24 }, { opacity: 1, y: 0, duration: .6, stagger: .08, ease: motionSettings.ease,
          scrollTrigger: { trigger: main, start: 'bottom 98%', toggleActions: 'play none none none' } });

        // A narrow edge blends the existing backgrounds without washing out text.
        main.querySelectorAll<HTMLElement>('.work-section, .diagnostic-section').forEach(section => {
          const edge = document.createElement('span');
          edge.className = 'section-color-edge'; edge.setAttribute('aria-hidden', 'true'); section.append(edge);
          gsap.fromTo(edge, { scaleY: 1, opacity: 1 }, { scaleY: 0, opacity: 0, ease: 'none', scrollTrigger: {
            trigger: section, start: 'top bottom', end: 'top 60%', scrub: true,
          } });
          cleanups.push(() => edge.remove());
        });
      }, main);
      let timer: ReturnType<typeof setTimeout>;
      const refresh = () => { clearTimeout(timer); timer = setTimeout(() => {
        ScrollTrigger.refresh();
        if (!aligned.current) {
          aligned.current = true;
          // Next resolves a route hash before desktop pins add their scroll space.
          // Restore that destination once, after the final layout is measurable.
          let target: HTMLElement | null = null;
          try { target = document.getElementById(decodeURIComponent(location.hash.slice(1))); } catch { /* Ignore malformed hashes. */ }
          target?.scrollIntoView({ block: 'start', behavior: 'instant' });
        }
      }, 100); };
      window.addEventListener('velour:layout', refresh);
      const details = main.querySelector('.service-details');
      // Opening long native details temporarily releases the pin instead of clipping copy.
      const onDetails = () => { if ((details as HTMLDetailsElement)?.open) { ScrollTrigger.getAll().filter(trigger => trigger.pin === stage).forEach(trigger => trigger.disable(true)); } else { ScrollTrigger.getAll().filter(trigger => trigger.pin === stage).forEach(trigger => trigger.enable()); } refresh(); };
      const stage = main.querySelector('.service-feature-web .service-stage');
      details?.addEventListener('toggle', onDetails);
      refresh();
      dispose = () => { clearTimeout(timer); window.removeEventListener('velour:layout', refresh); details?.removeEventListener('toggle', onDetails); cleanups.forEach(fn => fn()); };
    }).catch(() => { dispose(); context?.revert(); });
    return () => { cancelled = true; dispose(); context?.revert(); };
  }, [enabled, tall, root]);
  return null;
}

const subscribeTall = (callback: () => void) => {
  const query = window.matchMedia('(min-height: 760px)');
  query.addEventListener('change', callback);
  return () => query.removeEventListener('change', callback);
};

export function HomeScenes({ root }: { root: RefObject<HTMLElement | null> }) {
  const { reduced, ambient } = useMotionPreferences();
  const tall = useSyncExternalStore(subscribeTall, () => window.matchMedia('(min-height: 760px)').matches, () => false);
  return <><HeroTimeline reduced={reduced} root={root} /><DesktopScenes enabled={ambient} tall={tall} root={root} /></>;
}


