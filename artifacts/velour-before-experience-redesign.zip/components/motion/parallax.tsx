'use client';

import { useLayoutEffect, useRef, type ReactNode } from 'react';
import { loadScrollMotion } from '@/lib/motion';
import { useMotionPreferences } from '../motion';

/** A dedicated transform layer: never wrap long copy or interactive controls. */
export function Parallax({ children, speed = 30, direction = 'up', className = '' }: {
  children: ReactNode; speed?: number; direction?: 'up' | 'down'; className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const { ambient } = useMotionPreferences();
  useLayoutEffect(() => {
    if (!ambient || !ref.current) return;
    let cancelled = false;
    let context: gsap.Context | undefined;
    void loadScrollMotion().then(({ gsap }) => {
      if (cancelled || !ref.current) return;
      const node = ref.current;
      const distance = Math.min(Math.abs(speed), 60) * (direction === 'up' ? -1 : 1);
      context = gsap.context(() => {
        // Timeline triggers measure on the next tick, after sibling one-shot reveals
        // have mounted. Immediate tween refresh can race those reveals at a deep link.
        gsap.timeline({ scrollTrigger: {
          trigger: node, start: 'top bottom', end: 'bottom top', scrub: true,
        } }).fromTo(node, { y: -distance / 2 }, { y: distance / 2, ease: 'none' });
      }, node);
    }).catch(() => context?.revert());
    return () => { cancelled = true; context?.revert(); };
  }, [ambient, direction, speed]);
  return <div ref={ref} className={`parallax-layer ${className}`}>{children}</div>;
}
