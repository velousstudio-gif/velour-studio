'use client';

import { useState, type ReactNode } from 'react';
import { motion, useMotionValue, useSpring } from 'framer-motion';
import { useMotionPreferences } from '../motion';

export function ProjectCursor({ children }: { children: ReactNode }) {
  const { ambient } = useMotionPreferences();
  const [inside, setInside] = useState(false);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const springX = useSpring(x, { stiffness: 180, damping: 25 });
  const springY = useSpring(y, { stiffness: 180, damping: 25 });
  return <div className={`project-cursor-area${ambient ? ' cursor-enabled' : ''}`} onPointerEnter={event => {
    if (!ambient || event.pointerType === 'touch') return;
    const rect = event.currentTarget.getBoundingClientRect();
    x.jump(event.clientX - rect.left - 42); y.jump(event.clientY - rect.top - 42);
    setInside(true);
  }} onPointerMove={event => {
    if (!ambient || event.pointerType === 'touch') return;
    const rect = event.currentTarget.getBoundingClientRect();
    x.set(event.clientX - rect.left - 42); y.set(event.clientY - rect.top - 42);
  }} onPointerLeave={() => setInside(false)}>
    {children}
    {ambient && <motion.span className="project-cursor" aria-hidden="true" style={{ x: springX, y: springY }} initial={false}
      animate={{ scale: inside ? 1 : 0, opacity: inside ? 1 : 0 }} transition={{ duration: .25 }}>VER<br />PROYECTO</motion.span>}
  </div>;
}
