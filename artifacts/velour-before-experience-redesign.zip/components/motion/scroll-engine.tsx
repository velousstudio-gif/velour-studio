'use client';

import { useEffect } from 'react';
import { usePathname } from 'next/navigation';
import { loadScrollMotion } from '@/lib/motion';

export function ScrollEngine({ enabled }: { enabled: boolean }) {
  const pathname = usePathname();
  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    let dispose = () => {};
    void Promise.all([loadScrollMotion(), import('lenis')]).then(([{ gsap, ScrollTrigger }, { default: Lenis }]) => {
      if (cancelled) return;
      const lenis = new Lenis({ duration: 1.1, lerp: 0, smoothWheel: true, wheelMultiplier: .9, syncTouch: false, stopInertiaOnNavigate: true,
        prevent: node => node.matches('dialog, textarea, select, [data-lenis-prevent]') });
      const tick = (seconds: number) => lenis.raf(seconds * 1000);
      const resize = () => lenis.resize();
      const unsubscribe = lenis.on('scroll', ScrollTrigger.update);
      gsap.ticker.add(tick);
      gsap.ticker.lagSmoothing(0);
      ScrollTrigger.addEventListener('refresh', resize);
      // Capture same-page anchors before Next's router so there is only one scroll owner.
      const onAnchor = (event: MouseEvent) => {
        if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        const link = (event.target as Element).closest<HTMLAnchorElement>('a[href]');
        if (!link || link.target === '_blank' || link.hasAttribute('download')) return;
        const url = new URL(link.href, location.href);
        if (url.origin !== location.origin || url.pathname !== location.pathname || url.search !== location.search || !url.hash) return;
        let id: string;
        try { id = decodeURIComponent(url.hash.slice(1)); } catch { return; }
        const target = document.getElementById(id);
        if (!target) return;
        event.preventDefault();
        event.stopPropagation();
        history.pushState(null, '', url.hash);
        // Lenis includes the root scroll-padding and target scroll-margin itself.
        lenis.scrollTo(target, { onComplete: () => {
          const hadTabindex = target.hasAttribute('tabindex');
          if (!hadTabindex) target.setAttribute('tabindex', '-1');
          target.focus({ preventScroll: true });
          if (!hadTabindex) target.addEventListener('blur', () => target.removeAttribute('tabindex'), { once: true });
        } });
      };
      document.addEventListener('click', onAnchor, true);
      dispose = () => {
        document.removeEventListener('click', onAnchor, true);
        ScrollTrigger.removeEventListener('refresh', resize);
        unsubscribe();
        gsap.ticker.remove(tick);
        lenis.destroy();
        gsap.ticker.lagSmoothing(500, 33);
      };
    }).catch(() => { /* Native scrolling remains functional if an optional chunk fails. */ });
    return () => { cancelled = true; dispose(); };
  }, [enabled, pathname]);
  return null;
}
