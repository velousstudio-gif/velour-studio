'use client';

import { MotionLink as Link, Reveal, TextReveal, ImageReveal, ParallaxArtwork, AnimatedButton, editorialEase, useMotionPreferences } from './motion';
import { AnimatedFAQ } from './animated-faq';
import { HomeScenes } from './motion/home-scenes';
import { ProjectCursor } from './motion/project-cursor';
import { Parallax } from './motion/parallax';
import { usePathname, useRouter } from 'next/navigation';
import { loadScrollMotion, refreshMotionLayout } from '@/lib/motion';
import Image from 'next/image';
import { useEffect, useRef, useState } from 'react';
import { motion, animate, stagger, useMotionValueEvent, useScroll } from 'framer-motion';
import { ArrowUpRight, ArrowDown, ArrowRight, Menu, X, Pause, Play, Check } from 'lucide-react';
import { siteContent } from '@/content/site-content';
import { contact, projects, faqs } from '@/lib/content';
import { ProjectVisual } from './project-visual';
import { ProjectMockup } from './mockup';
import { ProjectDiagnostic, QuestionForm } from './contact-form';
import { Logo } from './brand-logo';
export { Logo } from './brand-logo';

const copy = siteContent.agency;
const home = siteContent.copy.home;

export function Header() {
  const [open, setOpen] = useState(false);
  const [compact, setCompact] = useState(false);
  const [down, setDown] = useState(false);
  const pathname = usePathname();
  const router = useRouter();
  const { reduced } = useMotionPreferences();
  const { scrollY } = useScroll();
  const lastScroll = useRef(0);
  useMotionValueEvent(scrollY, 'change', current => {
    setCompact(current > 60);
    if (Math.abs(current - lastScroll.current) < 8) return;
    setDown(current > 60 && current > lastScroll.current);
    lastScroll.current = current;
  });
  const dialog = useRef<HTMLDialogElement>(null);
  const toggle = useRef<HTMLButtonElement>(null);
  const closing = useRef(false);
  useEffect(() => {
    const modal = dialog.current;
    if (!open || !modal) return;
    const previousOverflow = document.body.style.overflow;
    const trigger = toggle.current;
    closing.current = false;
    modal.showModal();
    document.body.style.overflow = 'hidden';
    const entrance = animate(modal, { opacity: [0, 1] }, { duration: reduced ? 0 : .3 });
    const menuLinks = animate(modal.querySelectorAll('nav a'), { opacity: [0, 1], y: [reduced ? 0 : 30, 0] }, { duration: reduced ? 0 : .4, delay: reduced ? 0 : stagger(.06), ease: editorialEase });
    const media = window.matchMedia('(min-width: 901px)');
    const closeOnDesktop = () => { if (media.matches) setOpen(false); };
    media.addEventListener('change', closeOnDesktop);
    return () => {
      modal.close();
      entrance.stop(); menuLinks.stop();
      document.body.style.overflow = previousOverflow;
      media.removeEventListener('change', closeOnDesktop);
      trigger?.focus();
    };
  }, [open, reduced]);
  async function closeMenu(href?: string) {
    if (closing.current) return;
    closing.current = true;
    if (dialog.current && !reduced) await Promise.all([
      animate(dialog.current.querySelectorAll('nav a'), { opacity: 0, y: 20 }, { duration: .2, delay: stagger(.03, { from: 'last' }), ease: editorialEase }),
      animate(dialog.current, { opacity: 0 }, { duration: .3, delay: .08 }),
    ]);
    setOpen(false);
    if (href) requestAnimationFrame(() => router.push(href));
  }
  const links = siteContent.navigation.map(([label, id]) => <Link href={siteContent.links[id as keyof typeof siteContent.links]} key={id}><span className="nav-mask"><span>{label}</span><span aria-hidden="true">{label}</span></span></Link>);
  return <header data-home-header={pathname === '/' || undefined} className={`site-header${compact && !open ? ' is-compact' : ''}${down && !open ? ' is-scrolling-down' : ''}`}><div className="container header-inner">
    <Logo intro={pathname === '/'} /><nav aria-label={copy.nav.label} className="navigation">{links}</nav>
    <div className="header-actions"><Link className="header-contact" href={siteContent.links.contact}>{copy.nav.contact}</Link><Link className="header-project" href={siteContent.links.form}>{home.hablemos}<span className="round-arrow"><ArrowUpRight size={17} aria-hidden="true" /></span></Link><button ref={toggle} className="menu-toggle" aria-controls="mobile-navigation" aria-expanded={open} aria-label={copy.nav.open} onClick={() => setOpen(true)}><Menu /></button></div>
    <dialog ref={dialog} id="mobile-navigation" data-lenis-prevent className="mobile-menu" aria-label={copy.nav.label} onCancel={event => { event.preventDefault(); void closeMenu(); }} onClose={() => setOpen(false)}>
      <div className="mobile-menu-top"><span>{copy.companyName}</span><button className="menu-close" aria-label={copy.nav.close} onClick={() => void closeMenu()}><X /></button></div>
      <nav aria-label={copy.nav.label}>{[...siteContent.navigation.map(([label,id]) => ({label, href:siteContent.links[id as keyof typeof siteContent.links]})), {label:copy.nav.contact,href:siteContent.links.contact}].map(({label,href}) => <a href={href} key={label} onClick={event => { event.preventDefault(); void closeMenu(href); }}>{label}<ArrowUpRight size={20} aria-hidden="true" /></a>)}</nav>
      <AnimatedButton className="button-dark" href={siteContent.links.form} onClick={event => { event.preventDefault(); void closeMenu(siteContent.links.form); }}>{home.hablemos}<ArrowUpRight size={18} /></AnimatedButton><span className="mobile-menu-colophon">{home.independent_by_design}</span>
    </dialog>
  </div></header>;
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  const { reduced } = useMotionPreferences();
  return <motion.div className="section-label motion-reveal" initial={reduced ? false : { x: -20, opacity: 0 }} whileInView={{ x: 0, opacity: 1 }} viewport={{ once: true, amount: .3 }} transition={{ duration: reduced ? 0 : .6, ease: editorialEase }}>{children}</motion.div>;
}
function HeroArtwork() {
  return <ImageReveal intro><div className="hero-artwork"><div className="hero-image"><Image src={siteContent.media.hero.src} alt={siteContent.media.hero.alt} fill sizes="(max-width: 540px) 170vw, (max-width: 900px) 100vw, 1328px" preload /></div><div className="artwork-caption"><span>{home.direccion_creativa_velour_studio}</span><p>{home.la_forma_cambia}<br /><em>{home.la_intencion_permanece}</em></p></div><div className="artwork-corner"><span>{home.exploracion_visual_001}</span><span className="artwork-mark" aria-hidden="true">V</span></div></div></ImageReveal>;
}
function Hero() {
  return <section className="hero agency-hero container" id="inicio" data-hero-intro="pending"><div className="hero-topline" data-hero="eyebrow"><span>{copy.hero.eyebrow}</span></div><TextReveal as="h1" intro>{copy.hero.title}</TextReveal><p className="hero-accent" data-hero="accent"><em>{copy.hero.accent}</em></p><div className="hero-bottom"><div className="hero-actions" data-hero="actions"><AnimatedButton className="button-dark" magnetic href={siteContent.links.form}>{copy.hero.primary}<ArrowUpRight size={18} /></AnimatedButton><a className="underlined-link" href={siteContent.links.works}>{copy.hero.secondary}<ArrowDown size={17} /></a></div><p data-hero="description">{copy.hero.description}</p></div><HeroArtwork /><div className="hero-colophon"><span>{home.estrategia_con_intencion_diseno_con_caracter}</span><a className="scroll-cue" href={siteContent.links.trust}>{copy.hero.scroll}<span aria-hidden="true" /></a></div></section>;
}

function TrustStrip() {
  return <section className="trust-strip container" id="confianza" aria-label={copy.trustLabel}>{copy.trust.map((item, i) => <Reveal delay={i * .08} key={item.title}><span className="trust-index">0{i + 1}</span><h2>{item.title}</h2><p>{item.description}</p></Reveal>)}</section>;
}
function TechnologyMarquee() {
  const [paused, setPaused] = useState(false);
  const { reduced } = useMotionPreferences();
  const ref = useRef<HTMLElement>(null);
  const loop = useRef<gsap.core.Tween | null>(null);
  useEffect(() => {
    if (reduced || !ref.current) return;
    let cancelled = false;
    let context: gsap.Context | undefined;
    let observer: IntersectionObserver | undefined;
    const section = ref.current;
    void loadScrollMotion().then(({ gsap }) => {
      if (cancelled) return;
      context = gsap.context(() => {
        loop.current = gsap.fromTo('.technology-track', { xPercent: -50 }, { xPercent: 0, duration: 50, ease: 'none', repeat: -1 });
      }, section);
      observer = new IntersectionObserver(([entry]) => {
        loop.current?.paused(!entry.isIntersecting || section.dataset.paused === 'true' || document.hidden);
      });
      observer.observe(section);
    }).catch(() => {});
    const visibility = () => loop.current?.paused(document.hidden || section.dataset.paused === 'true' || section.getBoundingClientRect().bottom < 0 || section.getBoundingClientRect().top > innerHeight);
    document.addEventListener('visibilitychange', visibility);
    return () => { cancelled = true; observer?.disconnect(); context?.revert(); loop.current = null; document.removeEventListener('visibilitychange', visibility); };
  }, [reduced]);
  useEffect(() => { loop.current?.paused(paused); }, [paused]);
  return <section ref={ref} data-paused={paused} className="technology-section" aria-labelledby="technology-heading"><div className="container technology-top"><h2 id="technology-heading">{copy.technology.label}</h2><button className="marquee-toggle" aria-label={paused ? copy.technology.play : copy.technology.pause} aria-pressed={paused} onClick={() => setPaused(!paused)}>{paused ? <Play size={14} /> : <Pause size={14} />}</button></div><div className="technology-window" onPointerEnter={() => loop.current?.timeScale(.25)} onPointerLeave={() => loop.current?.timeScale(1)}><div className="technology-track">{[0, 1].map(set => <ul aria-hidden={set === 1 ? true : undefined} key={set}>{copy.technology.names.map(name => <li key={name}>{name}<span aria-hidden="true">✳</span></li>)}</ul>)}</div></div></section>;
}

function ServiceFeature({ type }: { type: 'web' | 'automation' }) {
  const service = siteContent.services[type];
  return <section className={`service-feature service-feature-${type} container`} id={type === 'web' ? 'web-commerce' : 'automation'}><div className="service-pin-shell"><div className="service-stage">
    <div className="service-feature-copy"><SectionLabel>{service.eyebrow}</SectionLabel><TextReveal>{service.title}</TextReveal><p className="feature-description">{service.description}</p><div className="feature-actions"><details className="service-details" onToggle={refreshMotionLayout}><summary>{service.detailLabel}<ArrowRight size={16} /></summary><p>{service.details}</p></details><a className="underlined-link" href={siteContent.links.form}>{copy.hero.primary}<ArrowUpRight size={16} /></a></div><dl className="capability-list">{service.capabilities.map(([name, description], index) => <Reveal delay={index * .07} key={name}><dt>{name}<ArrowUpRight size={13} aria-hidden="true" /></dt><dd>{description}</dd></Reveal>)}</dl></div>
    <ImageReveal className="service-feature-art"><figure>{type === 'web' ? <div className="web-composition"><ProjectMockup kind="fashion" /><ProjectMockup kind="recruitment" /><div className="service-shopify-scene" aria-hidden="true"><ProjectMockup kind="fashion" /></div></div> : <div className="device-composition" aria-hidden="true"><div className="device-browser"><div className="browser-chrome"><i /><i /><i /><span>{copy.interface.label}</span></div><div className="booking-screen"><span className="booking-brand">{copy.interface.wordmark}</span><div className="booking-title">{copy.interface.title}</div><p>{copy.interface.description}</p><div className="booking-date">{copy.interface.date}<ArrowDown size={14} /></div><div className="booking-times">{copy.interface.times.map(time => <span key={time}>{time}</span>)}</div><span className="booking-confirm">{copy.interface.button}<ArrowUpRight size={14} /></span></div></div><div className="device-phone"><span className="phone-speaker" /><span className="booking-brand">{copy.interface.wordmark}</span><Check size={28} strokeWidth={1} /><span className="phone-title">{copy.interface.status}</span><span className="phone-rule" /></div><span className="device-note">{copy.interface.note}</span></div>}<figcaption>{service.visualCaption}</figcaption></figure></ImageReveal>
  </div></div></section>;
}
function ProcessStep({ step, index }: { step: (typeof siteContent.process)[number]; index: number }) {
  return <li><span className="timeline-number">0{index + 1}</span><div><div className="timeline-meta"><span>{step.timing}</span>{step.approval && <span className="approval-badge">{copy.process.approval}</span>}</div><h3>{step.title}</h3><p>{step.description}</p>{step.deliverables.length > 0 && <ul aria-label={copy.process.deliverables}>{step.deliverables.map(item => <li key={item}>{item}</li>)}</ul>}</div></li>;
}
function ProcessTimeline() {
  return <section className="agency-process container editorial-section" id="proceso"><div className="process-intro"><SectionLabel>{copy.process.label}</SectionLabel><TextReveal>{copy.process.title}</TextReveal><p>{copy.process.description}</p><small>{copy.process.note}</small></div><div className="process-track"><span className="process-rail" aria-hidden="true"><span /></span><ol className="timeline">{siteContent.process.map((step, index) => <ProcessStep key={step.title} step={step} index={index} />)}</ol></div></section>;
}

function SelectedWork() {
  return <section className="work-section dark-section" id="proyectos"><div className="container"><div className="section-heading"><div><SectionLabel>{copy.work.label}</SectionLabel><TextReveal>{copy.work.title}<br /><em>{copy.work.accent}</em></TextReveal></div><p>{projects.some(project => project.status === 'demo') ? copy.work.demo : copy.work.real}</p></div><div className="work-list">{projects.map((project, index) => <article className={`work-item work-${project.kind}`} key={project.slug}><Link className="work-image-link" href={`/proyectos/${project.slug}`} aria-label={`${copy.work.caseLink}: ${project.name}`}><ProjectCursor><ImageReveal><ParallaxArtwork><ProjectVisual project={project} /></ParallaxArtwork></ImageReveal></ProjectCursor><span className="work-view-label" aria-hidden="true">{copy.work.caseLink}</span><span className="work-open"><ArrowUpRight size={24} /></span></Link><div className="work-caption"><div><span className="work-index">{home.proyecto_0}{index + 1}{project.status === 'demo' && home.concepto}</span><h3><Link href={`/proyectos/${project.slug}`}>{project.name}</Link></h3><span className="work-sector">{project.sector}</span></div><div><span className="work-category">{project.category} / {project.year}</span><p>{project.description}</p><ul className="project-tags">{project.tech.map(tag => <li key={tag}>{tag}</li>)}</ul></div></div></article>)}</div></div></section>;
}
function Studio() {
  return <section className="about-section dark-section" id="nosotros"><div className="container about-layout"><div className="studio-art" aria-hidden="true"><span className="studio-art-top">{home.independiente_por_naturaleza}</span><div className="studio-orbit orbit-one" /><div className="studio-orbit orbit-two" /><Parallax speed={40}><span className="studio-art-letter">V</span></Parallax><span className="studio-art-bottom">{home.diseno_con_una_mirada_propia}</span></div><Reveal className="about-copy"><SectionLabel>{home.el_estudio}</SectionLabel><TextReveal>{home.disenamos_con_intencion}<br /><em>{home.desarrollamos_con_proposito}</em></TextReveal><p className="about-intro">{home.velour_studio_es_un_estudio_digital_independiente}</p><a className="underlined-link" href={siteContent.links.form}>{home.conozcamonos}<ArrowUpRight size={19} /></a></Reveal></div></section>;
}
function ConversionCTA() {
  return <section className="conversion-cta dark-section"><div className="cta-light" aria-hidden="true" /><div className="cta-monogram" aria-hidden="true"><Image src="/brand/monogram-light.png" alt="" width={1254} height={1254} sizes="(max-width: 900px) 50vw, 500px" /></div><div className="container"><SectionLabel>{copy.cta.label}</SectionLabel><div className="cta-heading"><TextReveal>{copy.cta.title}</TextReveal></div><div className="conversion-bottom"><p>{copy.cta.description}</p><div className="cta-actions"><AnimatedButton className="primary" magnetic href={siteContent.links.form}>{copy.cta.primary}<ArrowUpRight size={18} /></AnimatedButton>{contact.whatsappHref && <a className="underlined-link" href={contact.whatsappHref} target="_blank" rel="noopener noreferrer">{copy.cta.secondary}<ArrowUpRight size={16} /></a>}</div></div><ul className="cta-notes">{copy.cta.notes.map(note => <li key={note}>{note}</li>)}</ul></div></section>;
}

function FAQ() {
  const [active, setActive] = useState<string | null>(null);
  const [closing, setClosing] = useState<string | null>(null);
  return <section className="agency-faq container editorial-section" id="faq"><div><SectionLabel>{copy.faq.label}</SectionLabel><TextReveal>{copy.faq.title}</TextReveal><p>{copy.faq.description}</p><a className="underlined-link" href={siteContent.links.questions}>{copy.faq.link}<ArrowDown size={16} /></a></div><div className="faqs">{faqs.map(({ id, question, answer }, index) => <AnimatedFAQ key={id} question={question} index={index} expanded={active === id} closing={closing === id} onToggle={() => { setClosing(active); setActive(active === id ? null : id); }} onClosed={() => setClosing(value => value === id ? null : value)}><p>{answer}</p>{id === 'payment' && <dl className="payment-options">{siteContent.paymentOptions.map(option => <div key={option.label}><dt>{option.label}</dt><dd>{option.description}</dd></div>)}</dl>}</AnimatedFAQ>)}</div></section>;
}
export default function Home({ contactEnabled = false }: { contactEnabled?: boolean }) {
  const main = useRef<HTMLElement>(null);
  return <><a className="skip-link" href="#main">{home.saltar_al_contenido}</a><Header /><main ref={main} id="main" className="home-main"><HomeScenes root={main} /><Hero /><TrustStrip /><TechnologyMarquee /><div id="servicios"><ServiceFeature type="web" /><ServiceFeature type="automation" /><section className="branding-feature container" id="branding"><SectionLabel>{siteContent.services.branding.label}</SectionLabel><TextReveal>{siteContent.services.branding.title}</TextReveal><p>{siteContent.services.branding.description}</p><a className="underlined-link" href={siteContent.links.form}>{siteContent.services.branding.cta}<ArrowUpRight size={18} /></a></section></div><ProcessTimeline /><SelectedWork /><Studio /><div className="cta-pin-shell"><ConversionCTA /></div><FAQ /><section className="question-section container" id="preguntas"><div><SectionLabel>{copy.question.label}</SectionLabel><TextReveal>{copy.question.title}</TextReveal><p>{copy.question.description}</p></div><QuestionForm enabled={contactEnabled} /></section><section className="diagnostic-section dark-section" id="contacto"><div className="container diagnostic-layout"><div className="diagnostic-intro"><SectionLabel>{copy.diagnostic.label}</SectionLabel><TextReveal>{copy.diagnostic.title}</TextReveal><p>{copy.diagnostic.description}</p><div className="direct-contact"><span>{copy.diagnostic.direct}</span>{contact.emailHref && <a className="contact-alternative" href={contact.emailHref}>{contact.email}<ArrowUpRight size={15} /></a>}{contact.whatsappHref && <a className="contact-alternative" href={contact.whatsappHref} target="_blank" rel="noopener noreferrer"><span>{copy.contactLabels.whatsapp} · {contact.whatsappDisplay}</span><ArrowUpRight size={15} /></a>}</div></div><div id="project-form"><ProjectDiagnostic enabled={contactEnabled} /></div></div></section></main><Footer /></>;
}
export function Footer() {
  const { reduced, ambient } = useMotionPreferences();
  const column = (index: number) => ({ className: 'motion-reveal', initial: reduced || ambient ? false as const : { y: 25, opacity: 0 }, whileInView: ambient ? undefined : { y: 0, opacity: 1 }, viewport: { once: true, amount: .1 }, transition: { duration: reduced ? 0 : .65, delay: reduced ? 0 : index * .08, ease: editorialEase } });
  return <footer className="footer dark-section" onFocusCapture={() => { if (ambient && (document.querySelector('.home-main')?.getBoundingClientRect().bottom ?? 0) > innerHeight) window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'instant' }); }}><div className="container"><div className="footer-top"><Logo /><motion.p {...column(1)}>{home.diseno_con_caracter}<br />{home.experiencias_con_proposito}{contact.address && <><br /><span>{contact.address}</span></>}</motion.p><motion.nav {...column(2)} aria-label="Servicios del estudio">{siteContent.footerServices.map(({label, link}) => <Link href={siteContent.links[link as keyof typeof siteContent.links]} key={label}>{label}</Link>)}</motion.nav><motion.nav {...column(3)} aria-label="Contacto y redes">{[
    { label: copy.contactLabels.email, detail: contact.email, href: contact.emailHref },
    { label: copy.contactLabels.instagram, href: contact.instagram },
    { label: copy.contactLabels.linkedin, href: contact.linkedin },
    { label: copy.contactLabels.whatsapp, detail: contact.whatsappDisplay, href: contact.whatsappHref },
  ].filter(({ href }) => Boolean(href)).map(({ label, detail, href }) => <a key={label} href={href} {...(/^https?:\/\//.test(href) ? { target: '_blank', rel: 'noopener noreferrer' } : {})}><span>{label}{detail && <><br />{label === copy.contactLabels.email ? <>{detail.split('@')[0]}@<wbr />{detail.split('@')[1]}</> : detail}</>}</span><ArrowUpRight size={13} /></a>)}<Link href={siteContent.links.home}>{home.volver_arriba}<ArrowUpRight size={13} /></Link></motion.nav></div><div className="footer-bottom"><span>{home.text_2026_velour_studio}</span><div><Link href={siteContent.links.privacy}>{home.privacy}</Link><Link href={siteContent.links.terms}>{home.terms}</Link></div><span>{home.independent_by_design}</span></div></div></footer>;
}
